
package shared.enums;

public enum SensorPosition
{
	START,
	END
}
