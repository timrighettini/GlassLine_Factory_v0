
package shared.enums;

/**
 * Enum for Conveyor Directions
 */
public enum ConveyorDirections
{
	UP,
	DOWN,
	RIGHT,
	LEFT
}
