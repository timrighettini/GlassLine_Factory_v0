package transducer;

public enum TransducerDebugMode
{
	NONE, EVENTS_ONLY, EVENTS_AND_ACTIONS, EVENTS_AND_ACTIONS_AND_SCHEDULER;
}
